package com.lcwd.user.service.Service.exception;

public class BookingException extends RuntimeException{

        public BookingException(String str){
            super(str) ;
        }
        public BookingException(){

        }
}
