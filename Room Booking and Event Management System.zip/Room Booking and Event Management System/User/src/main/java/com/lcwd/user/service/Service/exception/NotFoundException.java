package com.lcwd.user.service.Service.exception;

public class NotFoundException extends RuntimeException{
	
	public NotFoundException(String str){
		super(str) ;
	}

}
