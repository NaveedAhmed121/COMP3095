package com.lcwd.user.service.Service.exception;

public class WalletException extends RuntimeException{

    public WalletException(String str){
        super(str) ;
    }

    public WalletException(){

    }
}
