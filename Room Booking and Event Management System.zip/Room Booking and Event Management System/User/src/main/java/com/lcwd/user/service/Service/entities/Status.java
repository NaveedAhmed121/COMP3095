package com.lcwd.user.service.Service.entities;

public enum Status {
    AVAILABLE, BOOKED
}
