package com.lcwd.user.service.Service.entities;

public enum PaymentStatus {
    PAID, UNPAID
}
