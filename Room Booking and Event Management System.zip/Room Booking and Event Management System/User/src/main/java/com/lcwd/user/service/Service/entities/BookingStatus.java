package com.lcwd.user.service.Service.entities;

public enum BookingStatus {
    CANCELLED,
    BOOKED,
    COMPLETED,

}
