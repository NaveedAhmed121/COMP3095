package com.lcwd.user.service.Service.exception;

public class HotelException extends RuntimeException{

            public HotelException(String str){
                super(str) ;
            }
            public HotelException(){

            }
}
