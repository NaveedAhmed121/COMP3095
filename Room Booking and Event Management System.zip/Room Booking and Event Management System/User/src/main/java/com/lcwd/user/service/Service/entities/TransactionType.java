package com.lcwd.user.service.Service.entities;

public enum TransactionType {
    DEBIT, CREDIT
}
