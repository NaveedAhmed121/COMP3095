package com.lcwd.hotel.entities;

public enum PaymentStatus {
    PAID, UNPAID
}
