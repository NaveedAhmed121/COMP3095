package com.lcwd.hotel.entities;

public enum Status {
    AVAILABLE, BOOKED
}
